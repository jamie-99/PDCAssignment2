package part2;

/**
 *
 * @author jamie
 */
public enum AgeGroup 
{
    Adult, Child, Student, Senior;
}
